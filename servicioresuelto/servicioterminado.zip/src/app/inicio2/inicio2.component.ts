import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inicio2',
  templateUrl: './inicio2.component.html',
  styleUrls: ['./inicio2.component.css']
})
export class Inicio2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
